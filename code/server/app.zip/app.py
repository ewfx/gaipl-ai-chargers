from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
import json
import os
from dotenv import load_dotenv
from typing import List, Dict, Any

load_dotenv()

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load data
with open("knowledge_base.json", "r") as f:
    knowledge_base = json.load(f)

with open("servicenow_apigee_incidents.json", "r") as f:
    incidents_data = json.load(f)

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def get_relevant_context(query: str) -> str:
    """Extract relevant context from knowledge base and incidents"""
    query_lower = query.lower()
    context_parts = []
    
    # Knowledge Base matches
    for item in knowledge_base:
        if (query_lower in item['Title'].lower() or 
            query_lower in item['Summary'].lower()):
            context_parts.append(
                f"KNOWLEDGE BASE:\n"
                f"ID: {item['KA Number']}\n"
                f"Title: {item['Title']}\n"
                f"Summary: {item['Summary']}\n"
            )

    # Incident matches
    for incident in incidents_data:
        if (query_lower in incident['Short Description'].lower() or 
            query_lower in incident['Incident Number'].lower()):
            context_parts.append(
                f"INCIDENT:\n"
                f"ID: {incident['Incident Number']}\n"
                f"Description: {incident['Short Description']}\n"
                f"State: {incident['State']}\n"
                f"Priority: {incident['Priority']}\n"
                f"Assigned: {incident['Assigned To']}\n"
            )
    
    return "\n".join(context_parts) if context_parts else "NO RELEVANT CONTEXT FOUND"

@app.get("/api/search")
async def search(query: str) -> Dict[str, List[Dict[str, Any]]]:
    """Search endpoint that only returns data from files"""
    results = []
    query_lower = query.lower()

    # Search knowledge base
    for item in knowledge_base:
        if (query_lower in item['Title'].lower() or 
            query_lower in item['Summary'].lower()):
            results.append({
                "type": "Knowledge Base",
                "id": item['KA Number'],
                "title": item['Title'],
                "summary": item['Summary']
            })

    # Search incidents
    for incident in incidents_data:
        if (query_lower in incident['Short Description'].lower() or 
            query_lower in incident['Incident Number'].lower()):
            results.append({
                "type": "Incident",
                "id": incident['Incident Number'],
                "title": incident['Short Description'],
                "state": incident['State'],
                "priority": incident['Priority'],
                "assigned_to": incident['Assigned To']
            })

    return {"results": results} if results else {
        "results": [{
            "type": "Notice",
            "message": "No matching records found in our knowledge base or incident reports."
        }]
    }

@app.post("/api/chat")
async def chat(message: Dict[str, Any]) -> Dict[str, Any]:
    """Chat endpoint with strict context limitation"""
    try:
        query = message.get("query", "").strip()
        if not query:
            raise HTTPException(status_code=400, detail="Empty query")
        
        chat_history = message.get("history", [])
        context = get_relevant_context(query)
        
        system_prompt = (
            "You are a technical support assistant for Apigee and ServiceNow systems. "
            "STRICT RULES YOU MUST FOLLOW:\n"
            "1. ONLY use information from the provided context\n"
            "2. If asked about anything not in context, respond: "
            "'I only have information about Apigee and ServiceNow systems from our knowledge base and incident records.'\n"
            "3. Never make up answers or provide information outside the context\n"
            "4. Be concise and technical\n\n"
            "CONTEXT:\n{context}"
        ).format(context=context)

        messages = [
            {"role": "system", "content": system_prompt},
            *[{"role": h["role"], "content": h["content"]} for h in chat_history[-4:]],
            {"role": "user", "content": query}
        ]

        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            temperature=0.2,
            max_tokens=300
        )

        ai_response = response.choices[0].message.content
        
        # Verify response stays within bounds
        if not any(
            kw in ai_response.lower() 
            for kw in ["apigee", "servicenow", "knowledge base", "incident"]
        ):
            ai_response = "I only have information about Apigee and ServiceNow systems from our knowledge base and incident records."

        return {
            "response": ai_response,
            "context_used": context  # For debugging
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)