from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
import json
import os
from dotenv import load_dotenv
import datetime
from typing import Dict, Any, List  # Added all required type imports

load_dotenv()

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load data
with open("knowledge_base.json", "r") as f:
    knowledge_base = json.load(f)

with open("servicenow_apigee_incidents.json", "r") as f:
    incidents_data = json.load(f)

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_search_summary(query: str, kb_results: List[Dict[str, Any]], incident_results: List[Dict[str, Any]]) -> str:
    print("\n=== Starting summary generation ===")
    
    try:
        print("\n=== Data Validation ===")
        if not kb_results:
            print("Warning: Empty KB results")
        else:
            print(f"First KB item keys: {list(kb_results[0].keys())}")
        
        if not incident_results:
            print("Warning: Empty incident results")
        else:
            print(f"First incident keys: {list(incident_results[0].keys())}")

        # Safe KB text generation with flexible key matching
        kb_text = []
        for item in kb_results:
            # Flexible key matching
            ka_key = next(
                (k for k in item.keys() 
                if 'ka' in k.lower() and 'number' in k.lower()),
                'KA Number'  # default if not found
            )
            title_key = next(
                (k for k in item.keys() 
                if 'title' in k.lower() or 'name' in k.lower()),
                'Title'  # default if not found
            )
            
            line = f"{item.get(ka_key, 'N/A')}: {item.get(title_key, 'Untitled')}"
            kb_text.append(line)
            print(f"Processed KB item: {line}")  # Debug each item
        
        kb_text = "\n".join(kb_text) if kb_text else "No KB matches found"
        
        # Similar flexible processing for incidents
        incident_text = []
        for item in incident_results:
            inc_key = next(
                (k for k in item.keys()
                if 'incident' in k.lower() and 'number' in k.lower()),
                'Incident Number'
            )
            desc_key = next(
                (k for k in item.keys()
                if 'description' in k.lower() or 'short' in k.lower()),
                'Short Description'
            )
            
            line = f"{item.get(inc_key, 'N/A')}: {item.get(desc_key, 'No description')}"
            incident_text.append(line)
        
        incident_text = "\n".join(incident_text) if incident_text else "No incident matches found"
        
        print("\n=== Generated Texts ===")
        print("KB Text Sample:", kb_text[:200] + ("..." if len(kb_text) > 200 else ""))
        print("Incident Text Sample:", incident_text[:200] + ("..." if len(incident_text) > 200 else ""))
        
        prompt = f"""
        Generate a structured summary for this search query:
        Query: "{query}"
        
        Knowledge Base Matches:
        {kb_text if kb_text else "No KB matches found"}
        
        Incident Matches:
        {incident_text if incident_text else "No incident matches found"}
        """
        print(prompt)
        print("Making API call to OpenAI...")
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "system", "content": prompt}],
            temperature=0.3,
            max_tokens=300,
            timeout=10.0
        )
        print("API call completed")
        
        return response.choices[0].message.content

    except Exception as e:
        print(f"Error in summary generation: {str(e)}")
        return f"Could not generate summary: {str(e)}"

@app.get("/api/search")
async def search(query: str):
    try:
        if not query.strip():
            return {"status": "error", "message": "Query cannot be empty"}

        query_lower = query.lower()
        # print(query_lower)
        kb_results = []
        incident_results = []

        # More flexible search in knowledge base
        for item in knowledge_base:
            # Search in both title and summary
            # print(f"{item['Title'].lower()} comparing with {query_lower}")
            title_match = query_lower in item['Title'].lower()
            summary_match = query_lower in item['Summary'].lower()
            
            if title_match or summary_match:
                print("Match found")
                kb_results.append({
                    "type": "Knowledge Base",
                    "id": item['KA Number'],
                    "title": item['Title'],
                    "summary": item['Summary'],
                    "match_type": "title" if title_match else "summary"
                })
            else:
                print("No match found in KB article")

        # More flexible search in incidents
        for incident in incidents_data:
            # Search in both incident number and description
            id_match = query_lower in incident['Incident Number'].lower()
            desc_match = query_lower in incident['Short Description'].lower()
            
            if id_match or desc_match:
                incident_results.append({
                    "type": "Incident",
                    "id": incident['Incident Number'],
                    "title": incident['Short Description'],
                    "state": incident['State'],
                    "priority": incident['Priority'],
                    "assigned_to": incident['Assigned To'],
                    "match_type": "id" if id_match else "description"
                })

        # Generate summary only if we have results
        summary = ""
        if kb_results or incident_results:
            print("Triggering LLM Insights")
            summary = generate_search_summary(query, kb_results, incident_results)

        return {
            "status": "success",
            "query": query,
            "summary": summary if summary else "No matches found in knowledge base or incidents",
            "kb_results": kb_results,
            "incident_results": incident_results,
            "timestamp": datetime.datetime.now().isoformat()
        }

    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "timestamp": datetime.datetime.now().isoformat()
        }

@app.post("/api/chat")
async def chat(message: Dict[str, Any]):
    try:
        query = message.get("query", "").strip()
        if not query:
            raise HTTPException(status_code=400, detail="Empty query")
        
        chat_history = message.get("history", [])
        context = get_relevant_context(query)
        
        # Prepare strict instructions for the AI
        system_prompt = (
            "You are a technical support assistant for Apigee and ServiceNow systems. "
            "STRICT RULES YOU MUST FOLLOW:\n"
            "1. ONLY use information from the provided context\n"
            "2. If asked about anything not in context, respond: "
            "'I only have information about Apigee and ServiceNow systems from our knowledge base and incident records.'\n"
            "3. Never make up answers or provide information outside the context\n"
            "4. Be concise and technical\n\n"
            "CONTEXT:\n{context}"
        ).format(context=context)

        messages = [
            {"role": "system", "content": system_prompt},
            *[{"role": h["role"], "content": h["content"]} for h in chat_history[-4:]],
            {"role": "user", "content": query}
        ]

        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            temperature=0.2,
            max_tokens=300
        )

        ai_response = response.choices[0].message.content
        
        # Verify response stays within bounds
        if not any(
            kw in ai_response.lower() 
            for kw in ["apigee", "servicenow", "knowledge base", "incident"]
        ):
            ai_response = "I only have information about Apigee and ServiceNow systems from our knowledge base and incident records."

        return {
            "response": ai_response,
            "context_used": context  # For debugging
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)