from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
import json
import os
from dotenv import load_dotenv
import datetime
from typing import Dict, Any, List  # Added all required type imports

load_dotenv()

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load data
with open("knowledge_base.json", "r") as f:
    knowledge_base = json.load(f)

with open("servicenow_apigee_incidents.json", "r") as f:
    incidents_data = json.load(f)

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_search_summary(query: str, kb_results: List[Dict[str, Any]], incident_results: List[Dict[str, Any]]) -> str:
    """
    RAG-style summary generation that provides full context to the LLM
    """
    print("\n=== Starting RAG-style summary generation ===")
    
    try:
        # Prepare the full context for RAG
        context = f"## KNOWLEDGE BASE ARTICLES ##\n {kb_results}"
        # for item in kb_results:
        #     context += f"""
        #     Article ID: {item.get('KA Number', 'N/A')}
        #     Title: {item.get('Title', 'Untitled')}
        #     Summary: {item.get('Summary', 'No summary available')}
        #     Last Updated: {item.get('Last Updated', 'Unknown')}
        #     {'-'*40}
        #     """
        print(f"\n======= Context of KB ====== \n {kb_results} \n")
        context += f"\n## RELATED INCIDENTS ##\n {incident_results}"
        # for item in incident_results:
        #     context += f"""
        #     Incident ID: {item.get('Incident Number', 'N/A')}
        #     Description: {item.get('Short Description', 'No description')}
        #     Status: {item.get('State', 'Unknown')}
        #     Priority: {item.get('Priority', 'Unknown')}
        #     Assigned To: {item.get('Assigned To', 'Unassigned')}
        #     Created: {item.get('Created On', 'Unknown')}
        #     {'-'*40}
        #     """
        
        print(f"Prepared context with {len(kb_results)} KB articles and {len(incident_results)} incidents")
        
        # RAG prompt that gives the LLM full context
        prompt = f"""
        You are a technical support assistant analyzing search results. 
        The user searched for: "{query}"
        
        Here is the complete context from our knowledge base and incident records:
        {context}
        
        Please provide:
        1. A concise technical summary of the most relevant information.
        2. Key insights connecting the knowledge base articles to incidents pertaining to Summary / fixes / approaches of the incidents.
        3. Recommended next steps or solutions only concentrating on resolution / technical approaches
        
        Structure your response with clear sections and bullet points where appropriate.
        """
        
        print("Making RAG API call to OpenAI...")
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "system", "content": prompt}],
            temperature=0.3,
            max_tokens=500,  # Increased for more comprehensive analysis
            timeout=20.0
        )
        
        result = response.choices[0].message.content
        print("RAG analysis completed successfully")
        return result
        
    except Exception as e:
        print(f"Error in RAG generation: {str(e)}")
        return f"Could not generate analysis: {str(e)}"

@app.get("/api/search")
async def search(query: str):
    try:
        if not query.strip():
            return {"status": "error", "message": "Query cannot be empty"}

        query_lower = query.lower()
        # print(query_lower)
        kb_results = []
        incident_results = []

        # More flexible search in knowledge base
        for item in knowledge_base:
            # Search in both title and summary
            # print(f"{item['Title'].lower()} comparing with {query_lower}")
            title_match = query_lower in item['Title'].lower()
            summary_match = query_lower in item['Summary'].lower()
            
            if title_match or summary_match:
                print("Match found")
                kb_results.append({
                    "type": "Knowledge Base",
                    "id": item['KA Number'],
                    "title": item['Title'],
                    "summary": item['Summary'],
                    "resolution" : item['ResolutionSteps'],
                    "match_type": "title" if title_match else "summary"
                })
            else:
                print("No match found in KB article")

        # More flexible search in incidents
        for incident in incidents_data:
            # Search in both incident number and description
            id_match = query_lower in incident['Incident Number'].lower()
            desc_match = query_lower in incident['Short Description'].lower()
            
            if id_match or desc_match:
                incident_results.append({
                    "type": "Incident",
                    "id": incident['Incident Number'],
                    "title": incident['Short Description'],
                    "state": incident['State'],
                    "priority": incident['Priority'],
                    "assigned_to": incident['Assigned To'],
                    "match_type": "id" if id_match else "description"
                })

        # Generate summary only if we have results
        summary = ""
        if kb_results or incident_results:
            print("Triggering LLM Insights")
            summary = generate_search_summary(query, kb_results, incident_results)

        return {
            "status": "success",
            "query": query,
            "summary": summary if summary else "No matches found in knowledge base or incidents",
            "kb_results": kb_results,
            "incident_results": incident_results,
            "timestamp": datetime.datetime.now().isoformat()
        }

    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "timestamp": datetime.datetime.now().isoformat()
        }

@app.post("/api/chat")
async def chat(message: Dict[str, Any]):
    try:
        query = message.get("query", "").strip()
        if not query:
            raise HTTPException(status_code=400, detail="Empty query")
        
        chat_history = message.get("history", [])
        context = get_relevant_context(query)
        
        # Prepare strict instructions for the AI
        system_prompt = (
            "You are a technical support assistant for Apigee and ServiceNow systems. "
            "STRICT RULES YOU MUST FOLLOW:\n"
            "1. ONLY use information from the provided context\n"
            "2. If asked about anything not in context, respond: "
            "'I only have information about Apigee and ServiceNow systems from our knowledge base and incident records.'\n"
            "3. Never make up answers or provide information outside the context\n"
            "4. Be concise and technical\n\n"
            "CONTEXT:\n{context}"
        ).format(context=context)

        messages = [
            {"role": "system", "content": system_prompt},
            *[{"role": h["role"], "content": h["content"]} for h in chat_history[-4:]],
            {"role": "user", "content": query}
        ]

        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            temperature=0.2,
            max_tokens=300
        )

        ai_response = response.choices[0].message.content
        
        # Verify response stays within bounds
        if not any(
            kw in ai_response.lower() 
            for kw in ["apigee", "servicenow", "knowledge base", "incident"]
        ):
            ai_response = "I only have information about Apigee and ServiceNow systems from our knowledge base and incident records."

        return {
            "response": ai_response,
            "context_used": context  # For debugging
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)